package com.google.blockly.android.demo;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.blockly.model.Input;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MeActivity extends AppCompatActivity{
    private ImageView ivSpin;
    private LinearLayout llMenu;
    private boolean state=false;
    private MenuFlash menuFlash;
    private String userPhoneOrEmail;
    private ImageView ivHomePage;
    private ImageView ivUserImage;
    private ImageView ivUserImageHead;
    private Button btnMeHead;
    private EditText etUserName;
    private EditText etUserSex;
    private EditText etUserPhone;
    private EditText etUserEmail;
    private EditText etUserBirthday;
    private TextView tvUserFloor;
    private TextView tvUserPraise;
    private TextView tvUserName;
    private String userName="";
    private String userSex="";
    private String userPhone="";
    private String userEmail="";
    private String userBirthday="";
    private LinearLayout llMeLeftTop;
    private ScrollView svMeCenter;
    private List<Map<String,Object>> dataList;
    private ImageView ivSetting;
    private ImageView ivMe;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_me);
        hidTitle();
        init();
        menuFlash=new MenuFlash(ivSpin,llMenu);
        menuFlash.play();

        //隐藏状态栏
        ivSpin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                menuFlash.click(state);
                if(state==false){
                    state=true;
                }else{
                    state=false;
                }
            }
        });
        //运行获取所有新的异步类
        final ShowAllInformationTASK showAllInformationTASK=new ShowAllInformationTASK(userPhoneOrEmail);
        showAllInformationTASK.execute();

        //修改头像
        btnMeHead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPopWindow();

            }
        });

        //修改用户名
        etUserName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                String nowUserName=etUserName.getText().toString();
                if(b==false) {
                    if (!userName.equals(nowUserName)) {
                        ShowAlertDialog("userName", userPhoneOrEmail, nowUserName, etUserName, userName);
                        tvUserName.setText(nowUserName);
                        userName=nowUserName;
                    }
                }
            }
        });
        etUserSex.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                String nowUserSex=etUserSex.getText().toString();
                Log.e("msg",nowUserSex);
                if(b==false) {
                    if (!userSex.equals(nowUserSex)) {
                        ShowAlertDialog("userSex", userPhoneOrEmail, nowUserSex, etUserSex, userSex);
                        userSex=nowUserSex;
                    }
                }
            }
        });
        etUserPhone.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                String nowUserPhone=etUserPhone.getText().toString();
                if(b==false) {
                    if (!userPhone.equals(nowUserPhone)) {
                        ShowAlertDialog("userPhone", userPhoneOrEmail, nowUserPhone, etUserPhone, userPhone);
                    }
                    if (userPhoneOrEmail.matches("^1[3|4|5|8][0-9]\\d{8}$")) {
                        userPhoneOrEmail = nowUserPhone;
                    }
                }
            }
        });
        etUserEmail.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                String nowUserEmail=etUserEmail.getText().toString();
                if(b==false) {
                    if (!userEmail.equals(nowUserEmail)) {
                        ShowAlertDialog("userEmail", userPhoneOrEmail, nowUserEmail, etUserEmail, userEmail);
                    }
                    if (userPhoneOrEmail.matches("[\\w!#$%&'*+/=?^_`{|}~-]+(?:\\.[\\w!#$%&'*+/=?^_`{|}~-]+)*@(?:[\\w](?:[\\w-]*[\\w])?\\.)+[\\w](?:[\\w-]*[\\w])?")) {
                        userPhoneOrEmail = nowUserEmail;
                    }
                }
            }
        });
        etUserBirthday.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                String nowUserBirthday=etUserBirthday.getText().toString();
                if(b==false) {
                    if (!userBirthday.equals(nowUserBirthday)) {
                        ShowAlertDialog("userBirthday", userPhoneOrEmail, nowUserBirthday, etUserBirthday, userBirthday);
                    }
                }
            }
        });

        ivHomePage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent();
                intent.putExtra("isAlter","yes");
                intent.putExtra("user",userPhoneOrEmail);
                intent.setClass(MeActivity.this,HomePage.class);
                startActivity(intent);
            }
        });

        llMeLeftTop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                svMeCenter.setLayoutMode(R.layout.layout_me_center);
            }
        });

        ivMe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MeActivity.this,"已经在我的页面啦",Toast.LENGTH_SHORT).show();
            }
        });

    }

    /**
     * 弹出选择头像的popWindow
     */
    public void showPopWindow(){
        //1.创建popupWindow显示view
        View view=getLayoutInflater().inflate(R.layout.layout_me_head,null);
        //2.创建PopUpWindow
        final PopupWindow popupWindow=new PopupWindow(MeActivity.this);
        //3.设置PopupWindow的长宽
        popupWindow.setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
        popupWindow.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
        //4.设置popupWindow显示的view
        popupWindow.setContentView(view);
        popupWindow.setOutsideTouchable(true);
        //5.获取相应控件
        GridView gridView=view.findViewById(R.id.gv_me_head);
        //6.获取数据
        initHeadImageData();
        //7.创建Adapter
        GridViewAdapter adapter=new GridViewAdapter(MeActivity.this,
                R.layout.layout_me_head_image,dataList);
        gridView.setAdapter(adapter);
        //8.设置监听器
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Log.e("popupWindow","点击按钮弹出头像");
                Map<String ,Object>map=dataList.get(i);
                int imageId=(int)map.get("images");
                //String strImage=String.valueOf(image);
                Log.e("popUpWindow","imageId:()"+imageId);
                ivUserImage.setImageResource(imageId);
                ivUserImageHead.setImageResource(imageId);
                popupWindow.dismiss();
                AlterUserImageTASK task=new AlterUserImageTASK(userPhoneOrEmail,imageId);
                task.execute();

            }
        });
        popupWindow.showAsDropDown(btnMeHead,-700,0);


    }
    /**
     * 创建Adapter
     */
    public class GridViewAdapter extends BaseAdapter{
        private Context context;
        private int itemLayoutId;
        private List<Map<String,Object>>datalist;
        public GridViewAdapter(Context context,int itemLayoutId,List<Map<String,Object>>datalist){
            this.context=context;
            this.itemLayoutId=itemLayoutId;
            this.datalist=datalist;
        }
        @Override
        public int getCount() {
            return dataList.size();
        }

        @Override
        public Object getItem(int i) {
            return datalist.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int position,
                            View convertView,
                            ViewGroup viewGroup) {
            if(convertView==null){
                LayoutInflater inflater=LayoutInflater.from(context);
                convertView=inflater.inflate(itemLayoutId,null);
                Log.e("GridViewAdapter","convertView");
            }
            ImageView imageView=convertView.findViewById(R.id.iv_me_head_images);
            Map<String,Object>map=dataList.get(position);
            imageView.setImageResource((int)map.get("images"));

            return convertView;
        }
    }



    /**
     * 初始化头像的信息
     */
    public void initHeadImageData(){
        int[] images={R.mipmap.head1,R.mipmap.head2,R.mipmap.head3,R.mipmap.head4,R.mipmap.head5,
                R.mipmap.head6,R.mipmap.head7,R.mipmap.head8,R.mipmap.head9,R.mipmap.head10,R.mipmap.head11,
                R.mipmap.head12,R.mipmap.head13,R.mipmap.p1,
                R.mipmap.p2,R.mipmap.p3,R.mipmap.p4,R.mipmap.p5,R.mipmap.p6,R.mipmap.p7,R.mipmap.p8,
                R.mipmap.p9,R.mipmap.p10,R.mipmap.p11,R.mipmap.p12,R.mipmap.p13,R.mipmap.p14,
                R.mipmap.p15,R.mipmap.p16,R.mipmap.sy1,R.mipmap.sy3,
                R.mipmap.pp1, R.mipmap.pp2,R.mipmap.pp3,R.mipmap.pp4,R.mipmap.pp5,R.mipmap.pp6,
                R.mipmap.pp7,R.mipmap.pp8,
                R.mipmap.ppp1, R.mipmap.ppp2,R.mipmap.ppp3,R.mipmap.ppp4,R.mipmap.ppp5,R.mipmap.ppp6,
                R.mipmap.ppp7,R.mipmap.ppp8,R.mipmap.ppp9, R.mipmap.ppp10,R.mipmap.ppp11,R.mipmap.ppp12,
                R.mipmap.ppp13,R.mipmap.ppp14, R.mipmap.ppp15,R.mipmap.ppp16,R.mipmap.ppp17, R.mipmap.ppp18,
                R.mipmap.ppp19,R.mipmap.ppp20,R.mipmap.ppp21,R.mipmap.ppp22,
                R.mipmap.ppp23,R.mipmap.ppp24,R.mipmap.ppp25,R.mipmap.ppp26};
        dataList=new ArrayList<Map<String,Object>>();
        for(int i=0;i<images.length;++i){
            Map<String,Object>map=new HashMap<String,Object>();
            map.put("images",images[i]);
            dataList.add(map);
        }


    }

    /**
     * 弹出修改信息的对话框
     */
    public void ShowAlertDialog(final String ty, final String pOrE,final String in,final EditText et,final String pIn){
        //1.创建构造器
        AlertDialog.Builder builder=new AlertDialog.Builder(MeActivity.this);
        //2.对构造器进行设置
        builder.setTitle("提示信息");
        builder.setMessage("是否修改为"+in+"?");
        //3.设置对话框按钮，并绑定监听器
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                AlterUserInformationTASK task=new AlterUserInformationTASK(ty,pOrE,in,et,pIn);
                task.execute();
            }
        });
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                et.setText(pIn);
            }
        });
        //4.使用构造器builder构造出一个AlertDialog对象
        AlertDialog alertDialog=builder.create();
        //5.设置对话框点击其他地方不消失
        alertDialog.setCancelable(false);
        //6.显示对话框
        alertDialog.show();


    }

    /**
     * 修改头像的异步类
     */
    public class AlterUserImageTASK extends AsyncTask{
        String userPhoneOrEmail;
        int imageId;
        public AlterUserImageTASK(String userPhoneOrEmail,int imageId){
            this.userPhoneOrEmail=userPhoneOrEmail;
            this.imageId=imageId;
        }

        @Override
        protected Object doInBackground(Object[] objects) {
            try {
                URL url=new URL("http://192.168.43.179:8080/xiaoxiaoyuan/alterUserImageServlet?userPhoneOrEmail="+userPhoneOrEmail+"&imageId="+imageId);
                HttpURLConnection conn= (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("content-type","utf-8");

                InputStream inputStream=conn.getInputStream();
                InputStreamReader inputStreamReader=new InputStreamReader(inputStream);
                BufferedReader reader=new BufferedReader(inputStreamReader);
                String str=reader.readLine();
                Log.e("MeActivity","获取到的输入流（字符串形式）"+str);
                JSONObject object=new JSONObject(str);
                if(object.getString("isAlter").equals("yes")){
                    Log.e("MeActivity","数据库中改变头像");
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
    /**
     * 确定修改用户信息后执行的异步类
     */
    public class AlterUserInformationTASK extends AsyncTask{
        private String type;
        private String userPhoneOrEmail;
        private String information;
        private EditText et;
        private String pInfor;
        public AlterUserInformationTASK(String type,String userPhoneOrEmail,String information,EditText et,String pInfor){
            this.type=type;
            this.userPhoneOrEmail=userPhoneOrEmail;
            this.information=information;
            this.et=et;
            this.pInfor=pInfor;
        }
        @Override
        protected Object doInBackground(Object[] objects) {
            try {
                URL url=new URL("http://192.168.43.179:8080/xiaoxiaoyuan/alterUserInformationServlet?type="+type+"&userPhoneOrEmail="+userPhoneOrEmail+"&information="+information);
                HttpURLConnection connection= (HttpURLConnection) url.openConnection();
                connection.setRequestProperty("content-type","utf-8");
                Log.e("alterInformationTask","此时应该连接上");

                InputStream inputStream=connection.getInputStream();
                InputStreamReader inputStreamReader=new InputStreamReader(inputStream);
                BufferedReader reader=new BufferedReader(inputStreamReader);
                String str=reader.readLine();
                Log.e("alterInformationTask","输入流中的信息（字符串形式）"+str);
                JSONObject object=new JSONObject(str);
                if(object.getString("isAlter").equals("yes")){
                    Log.e("alterInformationTask","修改信息成功");
                }else{
                    et.setText(pInfor);
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }


            return null;
        }
    }


    public class ShowAllInformationTASK extends AsyncTask{
        String phoneOrEmail;
        public ShowAllInformationTASK(String phoneOrEmail){
            this.phoneOrEmail=phoneOrEmail;
        }

        @Override
        protected Object doInBackground(Object[] objects) {
            try {
                URL url=new URL("http://192.168.43.179:8080/xiaoxiaoyuan/showAllInformationServlet?userPhoneOrEmail="+phoneOrEmail);
                HttpURLConnection connection= (HttpURLConnection) url.openConnection();
                connection.setRequestProperty("content-type","utf-8");
                Log.e("MeActivity","此时应获取到连接");

                InputStream inputStream=connection.getInputStream();
                InputStreamReader inputStreamReader=new InputStreamReader(inputStream);
                BufferedReader reader=new BufferedReader(inputStreamReader);
                String str=reader.readLine();
                Log.e("MeActivity","输入流中的信息（字符串形式）"+str);
                JSONObject object=new JSONObject(str);
                //用户头像
                if(Integer.valueOf(object.getString("userImage"))!=0 ){
                    int imageId=Integer.valueOf(object.getString("userImage"));
                    ivUserImage.setImageResource(imageId);
                    ivUserImageHead.setImageResource(imageId);

                }
                //用户名
                if(object.getString("userName")==null || "".equals(object.getString("userName"))){
                    etUserName.setHint("为自己想一个喜欢的名字吧！");
                    etUserName.setTextSize(15);
                    tvUserName.setHint("未编辑用户名");
                }else{
                    etUserName.setText(object.getString("userName"));
                    tvUserName.setText(object.getString("userName"));
                    userName=object.getString("userName");
                }
                //用户性别
                if(object.getString("userSex")==null || "".equals(object.getString("userSex"))){
                    etUserSex.setHint("填上自己的性别吧！");
                    etUserSex.setTextSize(15);
                }else{
                    etUserSex.setText(object.getString("userSex"));
                    userSex=object.getString("userSex");
                }
                //手机号码
                if(object.getString("userPhone")==null || "".equals(object.getString("userPhone"))){
                    etUserPhone.setHint("手机号码也很重要哦！");
                    etUserPhone.setTextSize(15);
                }else{
                    etUserPhone.setText(object.getString("userPhone"));
                    userPhone=object.getString("userPhone");
                }
                //电子邮件
                if(object.getString("userEmail")==null || "".equals(object.getString("userEmail"))){
                    etUserEmail.setHint("邮箱可以方便您的登录！");
                    etUserEmail.setTextSize(15);
                }else{
                    etUserEmail.setText(object.getString("userEmail"));
                    userEmail=object.getString("userEmail");
                }
                //出生日期
                if(object.getString("userBirthday")==null || "".equals(object.getString("userBirthday"))){
                    etUserBirthday.setHint("例如：2000-2-2，年-月-日");
                    etUserBirthday.setTextSize(15);
                }else{
                    etUserBirthday.setText(object.getString("userBirthday"));
                    userBirthday=object.getString("userBirthday");
                }
                //现在层数
                tvUserFloor.setText(object.getString("userCurrentFloor"));
                //点赞数
                tvUserPraise.setText(object.getString( "userPraise"));
                //Email

                Log.e("ShowAllInformationTASK",object.getString("userCurrentFloor")+"");
                Log.e("ShowAllInformationTASK",object.getString("userPraise")+"");


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }


            return null;
        }
    }

    /**
     * 初始化控件
     */
    public void init(){
        ivSpin=findViewById(R.id.iv_spin);
        llMenu=findViewById(R.id.ll_menu);
        Intent intent=getIntent();
        userPhoneOrEmail=intent.getStringExtra("user");
        etUserName=findViewById(R.id.et_userName);
        etUserSex=findViewById(R.id.et_userSex);
        etUserPhone=findViewById(R.id.et_userPhone);
        etUserEmail=findViewById(R.id.et_userEmail);
        etUserBirthday=findViewById(R.id.et_userBirthday);
        tvUserFloor=findViewById(R.id.tv_userFloor);
        tvUserPraise=findViewById(R.id.tv_userPraise);
        tvUserName=findViewById(R.id.tv_userName);
        ivHomePage=findViewById(R.id.iv_HomePage);
        llMeLeftTop=findViewById(R.id.ll_me_left_top);
        svMeCenter=findViewById(R.id.sv_me_center);
        btnMeHead=findViewById(R.id.btn_exitUserImage);
        ivUserImage=findViewById(R.id.iv_userImage);
        ivUserImageHead=findViewById(R.id.iv_head);
        ivSetting=findViewById(R.id.iv_setting);
        ivSetting.setVisibility(View.INVISIBLE);
        ivMe=findViewById(R.id.iv_me);
    }

    private void hidTitle(){
        Window window = getWindow();
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }

        //定义全屏参数
        int flag= WindowManager.LayoutParams.FLAG_FULLSCREEN;
        //设置当前窗体为全屏显示
        window.setFlags(flag, flag);
    }
}
