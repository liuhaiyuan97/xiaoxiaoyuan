package com.google.blockly.android.demo;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public  class RunActivity extends AppCompatActivity implements View.OnTouchListener {
    //位置坐标数组（Y_H数组）
    private int x[]={2,35,72,104,138,170};
    //过程变量
    private int y,i;
    //初始化getY_H()相对坐标;
    private int Y_H =0;
    //定义当前用户的闯关数
    private static int floor=1;
    private static String user="";
    private static int currentFloor=1;
    private Button btnReturn;
    private Button[] btns;
    private static String questionName="";
    private static String questionContent="";
    private static String questionResult="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_run);

        Window window = getWindow();
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        //隐藏状态栏
        //定义全屏参数
        int flag = WindowManager.LayoutParams.FLAG_FULLSCREEN;
        //设置当前窗体为全屏显示
        window.setFlags(flag, flag);

        //1，初始化

        initButton();
        initView();

        //给每个按钮设置点击事件
        for(int i=0;i<48;i++){
            final int questionID = i+1;
            btns[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Log.e("RunActivity","关卡："+ questionID +"");
                    currentFloor=questionID;
                    Log.e("RunActivity","运行获取该题内容的异步类，里面包含弹出框");
                    if(currentFloor<=floor) {
                        GetQuestionContentTASK getQuestionContentTASK = new GetQuestionContentTASK(questionID);
                        getQuestionContentTASK.execute();
                        Log.e("RunActivity", "运行弹出题目内容的异步类");
                    }
                    if(currentFloor>20 && floor>20){
                        Toast.makeText(RunActivity.this,"暂未开启",Toast.LENGTH_SHORT).show();
                    }


                }
            });
        }

        //2，绑定触摸监听事件
//        SlowScrollView slowScrollView = findViewById(R.id.sv);
//        slowScrollView.setOnTouchListener(this);
        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent();
                intent.setClass(RunActivity.this,HomePage.class);
                startActivity(intent);
            }
        });


    }

    private void initButton(){
        //获取button
        Button btn_0 = findViewById(R.id.btn_0);Button btn_10 = findViewById(R.id.btn_10);Button btn_20 = findViewById(R.id.btn_20);Button btn_30 = findViewById(R.id.btn_30);Button btn_40 = findViewById(R.id.btn_40);
        Button btn_1 = findViewById(R.id.btn_1);Button btn_11 = findViewById(R.id.btn_11);Button btn_21 = findViewById(R.id.btn_21);Button btn_31 = findViewById(R.id.btn_31);Button btn_41 = findViewById(R.id.btn_41);
        Button btn_2 = findViewById(R.id.btn_2);Button btn_12 = findViewById(R.id.btn_12);Button btn_22 = findViewById(R.id.btn_22);Button btn_32 = findViewById(R.id.btn_32);Button btn_42 = findViewById(R.id.btn_42);
        Button btn_3 = findViewById(R.id.btn_3);Button btn_13 = findViewById(R.id.btn_13);Button btn_23 = findViewById(R.id.btn_23);Button btn_33 = findViewById(R.id.btn_33);Button btn_43 = findViewById(R.id.btn_43);
        Button btn_4 = findViewById(R.id.btn_4);Button btn_14 = findViewById(R.id.btn_14);Button btn_24 = findViewById(R.id.btn_24);Button btn_34 = findViewById(R.id.btn_34);Button btn_44 = findViewById(R.id.btn_44);
        Button btn_5 = findViewById(R.id.btn_5);Button btn_15 = findViewById(R.id.btn_15);Button btn_25 = findViewById(R.id.btn_25);Button btn_35 = findViewById(R.id.btn_35);Button btn_45 = findViewById(R.id.btn_45);
        Button btn_6 = findViewById(R.id.btn_6);Button btn_16 = findViewById(R.id.btn_16);Button btn_26 = findViewById(R.id.btn_26);Button btn_36 = findViewById(R.id.btn_36);Button btn_46 = findViewById(R.id.btn_46);
        Button btn_7 = findViewById(R.id.btn_7);Button btn_17 = findViewById(R.id.btn_17);Button btn_27 = findViewById(R.id.btn_27);Button btn_37 = findViewById(R.id.btn_37);Button btn_47 = findViewById(R.id.btn_47);
        Button btn_8 = findViewById(R.id.btn_8);Button btn_18 = findViewById(R.id.btn_18);Button btn_28 = findViewById(R.id.btn_28);Button btn_38 = findViewById(R.id.btn_38);
        Button btn_9 = findViewById(R.id.btn_9);Button btn_19 = findViewById(R.id.btn_19);Button btn_29 = findViewById(R.id.btn_29);Button btn_39 = findViewById(R.id.btn_39);
        btns = new Button[]{btn_0,btn_1,btn_2,btn_3,btn_4,btn_5,btn_6,btn_7,btn_8,btn_9,
                btn_10,btn_11,btn_12,btn_13,btn_14,btn_15,btn_16,btn_17,btn_18,btn_19,
                btn_20,btn_21,btn_22,btn_23,btn_24,btn_25,btn_26,btn_27,btn_28,btn_29,
                btn_30,btn_31,btn_32,btn_33,btn_34,btn_35,btn_36,btn_37,btn_38,btn_39,
                btn_40,btn_41,btn_42,btn_43,btn_44,btn_45,btn_46,btn_47};
    }
    @SuppressLint("ResourceAsColor")
    private void changeButtonColor() {

        for(i = 0;i<48;i++){
            btns[i].setTextColor(R.color.white);
            if(i<(floor-1)){
                btns[i].setText(i+1+"");
                btns[i].setBackgroundDrawable(getResources().getDrawable(R.mipmap.guan2));
            }else if(i==(floor-1)){
                btns[i].setText(i+1+"");
                btns[i].setBackgroundDrawable(getResources().getDrawable(R.mipmap.guan1));
            }else{
                btns[i].setText(i+1+"");
                btns[i].setEnabled(true);
                btns[i].setBackgroundDrawable(getResources().getDrawable(R.mipmap.guan0));
            }
        }
    }

    //初始化控件
    private void initView() {
        btnReturn=findViewById(R.id.fanhui);
        final int height = getHeight();
        final SlowScrollView scrollView = findViewById(R.id.sv);
        scrollView.post(new Runnable(){
            @Override
            public void run(){
                scrollView.smoothScrollToSlow(0,x[0]*height/200,1500);
            }
        });

        //3.获取积分
        Intent intent=getIntent();
        user=intent.getStringExtra("user");
        Log.e("RunActivity","user:"+user);
        GetFloorTASK getFloorTASK=new GetFloorTASK(user);
        getFloorTASK.execute();


    }


    @SuppressLint("ValidFragment")
    public static class QuestionCustomDialog extends DialogFragment {

        private TextView tvQuestionName;
        private TextView tvQuestionContent;
        private Button btnQuestionBegin;
        private Button btnQuestionCancle;

        public View onCreateView(@NonNull LayoutInflater inflater,
                                 @Nullable ViewGroup container,
                                 @Nullable Bundle savedInstanceState) {
            Log.e("RunActivity","弹出闯关框的onCreateView方法");
            //设置透明度状态
            getDialog().getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

            View view=inflater.inflate(R.layout.layout_run_to_adjust,null);
            tvQuestionName=view.findViewById(R.id.tv_question_name);
            tvQuestionContent=view.findViewById(R.id.tv_question_content);
            btnQuestionBegin=view.findViewById(R.id.btn_question_begin);
            btnQuestionCancle=view.findViewById(R.id.btn_question_cancle);
            Log.e("弹出框",questionName+":"+questionContent);
            tvQuestionName.setText(questionName);
            tvQuestionContent.setText(questionContent);
            QuestionCustomDialogListener listener=new QuestionCustomDialogListener();
            Log.e("QuestionCustomDialog","创建一个监听器对象");
            btnQuestionBegin.setOnClickListener(listener);
            btnQuestionCancle.setOnClickListener(listener);

            return view;
        }

        @Override
        public void onResume() {
            super.onResume();
            getDialog().getWindow().setLayout(dip2px(getContext(),425),dip2px(getContext(),310));
        }

        private class QuestionCustomDialogListener implements View.OnClickListener {

            @Override
            public void onClick(View view) {
                switch(view.getId()){
                    case R.id.btn_question_begin:
                        Log.e("弹出框","点击确定按钮");
                        Intent intent=new Intent();
                        intent.setClass(getContext(),AdjustActivity.class);
                        intent.putExtra("user",user);
                        intent.putExtra("floor",floor);
                        intent.putExtra("currentFloor",currentFloor);
                        Log.e("RunActivity","floor:"+floor+" currentFloor:"+currentFloor);
                        intent.putExtra("questionContent",questionContent);
                        intent.putExtra("questionResult",questionResult);
                        startActivity(intent);
                        getDialog().dismiss();
                        break;
                    case R.id.btn_question_cancle:
                        Log.e("弹出框","点击取消按钮");
                        getDialog().dismiss();
                        break;

                }
            }
        }
    }
    //获得关数的异步类
    public class GetFloorTASK extends AsyncTask {
        String user;
        public GetFloorTASK(String user){
            this.user=user;
        }
        @Override
        protected Object doInBackground(Object[] objects) {
            try {
                String str = "http://192.168.43.179:8080/xiaoxiaoyuan/getFloorByUserServlet?user="+user;
                URL url = new URL(str);
                HttpURLConnection connection = (HttpURLConnection)url.openConnection();
                //设置请求参数
                connection.setRequestProperty("contentType","utf-8");

                InputStream is = connection.getInputStream();
                InputStreamReader inputStreamReader = new InputStreamReader(is);
                BufferedReader reader = new BufferedReader(inputStreamReader);
                String res = reader.readLine();
                Log.e("GETTASK","获取到输入流（字符串形式）:"+res);
                if(res!=null){
                    JSONObject object=new JSONObject(res);
                    floor=Integer.valueOf(object.getString("floor"));
                    Log.e("floor:",floor+"");
                }

                //4，根据数组改变button颜色
                changeButtonColor();

                reader.close();
                inputStreamReader.close();
                is.close();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }
    }
    public class GetQuestionContentTASK extends AsyncTask{
        int questionId;
        public GetQuestionContentTASK(int questionId){
            this.questionId=questionId;
        }
        @Override
        protected Object doInBackground(Object[] objects) {

            try {
                URL url=new URL("http://192.168.43.179:8080/xiaoxiaoyuan/getQuestionContentServlet?questionId="+questionId);
                HttpURLConnection connection= (HttpURLConnection) url.openConnection();
                connection.setRequestProperty("content-type","utf-8");

                InputStream inputStream=connection.getInputStream();
                InputStreamReader inputStreamReader=new InputStreamReader(inputStream);
                BufferedReader reader=new BufferedReader(inputStreamReader);
                String str=reader.readLine();
                Log.e("RunActivity","获取到输入流中的信息（字符串形式）："+str);

                JSONObject object=new JSONObject(str);
                questionName=object.getString("questionName");
                questionContent=object.getString("questionContent");
                questionResult=object.getString("questionResult");
                Log.e("RunActivity","questionName:"+questionName);
                Log.e("RunActivity","questionContent:"+questionContent);
                Log.e("RunActivity","questionResult:"+questionResult);

                QuestionCustomDialog dialog=new QuestionCustomDialog();
                Log.e("RunActivity","创建弹出框对象");
                dialog.setCancelable(false);
                dialog.show(getSupportFragmentManager(),"");
                Log.e("RunActivity","将Dialog对象显示出来");
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
    //重写监听事件
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        switch (event.getAction()) {

            case MotionEvent.ACTION_DOWN:
                //按下
                Y_H = getY_H();
                Log.e("test",Y_H+"");
                break;
            //case MotionEvent.ACTION_MOVE:
            //移动


            //break;
            case MotionEvent.ACTION_UP:
                //松开
                //获取移动前的位置
                for(i=0;i<=5;i++){
                    if(i==5){
                        break;
                    }else if(Y_H<x[i+1]-5){
                        break;
                    }
                }
                //判断上划下划
                //滑动
                final int height = getHeight();
                final SlowScrollView scrollView = findViewById(R.id.sv);
                scrollView.post(new Runnable(){
                    @Override
                    public void run(){
                        scrollView.smoothScrollToSlow(0,x[i]*height/200,1000);
                    }
                });
                break;
        }
        return super.onTouchEvent(event);
    }

    //获取当前界面的位置 当前Y坐标*100/背景长度
    public int getY_H(){
        final int height = getHeight();
        SlowScrollView slowScrollView = findViewById(R.id.sv);
        WindowManager wm = this.getWindowManager();
        final int height1 = wm.getDefaultDisplay().getHeight();
        slowScrollView.setOnScrollChangeListener(new SlowScrollView.OnScrollChangeListener() {

            @Override

            public void onScrollChange(NestedScrollView nestedScrollView, int i, int i1, int i2, int i3) {
                int p1 = dip2px(RunActivity.this,i1);
                int d1 = px2dp(RunActivity.this,p1);
                y = d1*200/height;
            }
        });

        return y;
    }

    //获取页面高度
    public int getHeight(){
        SlowScrollView scrollView = findViewById(R.id.sv);
        int height = scrollView.getChildAt(0).getHeight();
        return height;
    }

    //将像素转换为px
    public static int dip2px(Context context, float dpValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }

    //将px转换为dp
    public static int px2dp(Context context, float pxValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (pxValue / scale + 0.5f);
    }

    //上一页点击事件
    public void topre(View view) {
        final int height = getHeight();
        final SlowScrollView scrollView = findViewById(R.id.sv);

        WindowManager wm = this.getWindowManager();
        int height1 = wm.getDefaultDisplay().getHeight();

        for(i=5;i>0;i--){
            if(getY_H()+height1*200/height>x[i]-1){
                i--;
                break;
            }
        }

        scrollView.post(new Runnable(){
            @Override
            public void run(){
                scrollView.smoothScrollToSlow(0,x[i]*height/200,1500);
            }
        });
        if(i==0){
            Button btn_pre = findViewById(R.id.btn_pre);
            btn_pre.setBackgroundDrawable(getResources().getDrawable(R.mipmap.nopre));
        }
        if(i==4){
            Button btn_next = findViewById(R.id.btn_next);
            btn_next.setBackgroundDrawable(getResources().getDrawable(R.mipmap.next));
        }
    }

    //下一页点击事件
    public void tonext(View view) {

        final int height = getHeight();
        final SlowScrollView scrollView = findViewById(R.id.sv);
        for(i=0;i<=4;i++){
            if(getY_H()<x[i+1]-1){
                i++;
                break;
            }
        }
        scrollView.post(new Runnable(){
            @Override
            public void run(){
                scrollView.smoothScrollToSlow(0,x[i]*height/200,1500);
            }
        });
        if(i==5){
            Button btn_next = findViewById(R.id.btn_next);
            btn_next.setBackgroundDrawable(getResources().getDrawable(R.mipmap.nonext));
        }
        if(i==1){
            Button btn_pre = findViewById(R.id.btn_pre);
            btn_pre.setBackgroundDrawable(getResources().getDrawable(R.mipmap.pre));
        }
    }


}
